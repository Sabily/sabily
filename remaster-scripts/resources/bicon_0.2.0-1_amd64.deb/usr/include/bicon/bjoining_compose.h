#ifndef __BJOINING_COMPOSE_H
#define __BJOINING_COMPOSE_H

#include "bjoining.h"

int bjoining_compose (
  unichar *s,
  int *len);

#endif
