#ifndef __BJOINING_CHARPROP_H
#define __BJOINING_CHARPROP_H

#include "bjoining.h"

int bjoining_isnonspacing (
  unichar u);

#endif
