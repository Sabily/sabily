#ifndef __BCONSOLE_LOG2CON_H
#define __BCONSOLE_LOG2CON_H

#include "bconsole.h"

int bconsole_log2con (
  unichar *str,
  int len,
  unichar *cstr,
  int *clen,
  int options);

#endif
